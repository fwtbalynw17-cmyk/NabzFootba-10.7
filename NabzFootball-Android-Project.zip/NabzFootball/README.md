# نبض فوتبال — Nabz Football

پروژه واقعی Android برای یک اپلیکیشن فوتبالی فارسی و RTL با طراحی مدرن سبز/سفید/قرمز.

## امکانات موجود

- خانه و آخرین اخبار آنلاین
- اخبار فوتبال ایران، جهان و فوری
- صفحه بازی‌های زنده با بروزرسانی ۱۵ ثانیه‌ای هنگام مشاهده
- مسابقات آینده
- جدول چند لیگ (انگلیس، اسپانیا، ایتالیا، آلمان، فرانسه و ایران)
- جست‌وجوی خبر، تیم و بازیکن
- صفحه جزئیات خبر + لینک منبع اصلی
- آیکون و لوگوی ارسالی شما
- RTL و زبان فارسی
- بدون تبلیغات
- ساختار Backend/Proxy برای مخفی‌کردن API Key در نسخه عمومی
- GitHub Actions برای ساخت APK بدون Android Studio

## معماری آنلاین

اپ به دو حالت کار می‌کند:

1. **Backend mode — پیشنهادی برای انتشار عمومی:** Android فقط به Backend متصل می‌شود و کلیدهای NewsAPI/API-Football روی سرور می‌مانند.
2. **Direct API mode — مناسب توسعه:** کلیدها از `local.properties` وارد BuildConfig می‌شوند. این روش برای APK عمومی امن نیست، چون کلید داخل اپ قابل استخراج است.

NewsAPI برای کشف و جست‌وجوی اخبار استفاده شده و API-Football برای fixtures، live، standings، teams و players. مستندات فعلی API-Football می‌گوید `/fixtures?live=all` برای بازی‌های زنده است و داده‌های fixtures/events حدود هر ۱۵ ثانیه به‌روزرسانی می‌شوند. NewsAPI نیز `/v2/everything` را برای جست‌وجوی مقاله‌ها ارائه می‌کند.

## تنظیم API در توسعه

فایل `local.properties.example` را به `local.properties` تبدیل کنید و یکی از حالت‌ها را تنظیم کنید:

```properties
BACKEND_URL=https://YOUR-BACKEND.example/
NEWS_API_KEY=
FOOTBALL_API_KEY=
```

اگر `BACKEND_URL` تنظیم شود، اپ از Backend استفاده می‌کند و کلیدها را مستقیماً به سرویس‌های خارجی نمی‌فرستد.

اگر Backend خالی باشد، برای توسعه می‌توان کلیدها را مستقیماً در `local.properties` قرار داد.

## راه‌اندازی Backend

مسیر: `backend/`

```bash
cd backend
cp .env.example .env
# کلیدهای واقعی را فقط داخل .env وارد کنید
npm install
npm start
```

Backend مسیرهای زیر را فراهم می‌کند:

- `/health`
- `/api/news`
- `/api/live`
- `/api/fixtures`
- `/api/standings`
- `/api/search`

برای انتشار، Backend را روی یک سرویس Node.js یا VPS مستقر کنید و URL آن را در `BACKEND_URL` قرار دهید.

## ساخت APK فقط با گوشی

### روش پیشنهادی: GitHub Actions

1. یک repository جدید در GitHub بسازید.
2. محتوای این ZIP را در repository آپلود کنید.
3. در Settings → Secrets and variables → Actions این Secretها را اضافه کنید:
   - `NABZ_BACKEND_URL` — آدرس Backend شما
   - در صورت استفاده مستقیم: `NABZ_NEWS_API_KEY`
   - در صورت استفاده مستقیم: `NABZ_FOOTBALL_API_KEY`
4. وارد تب **Actions** شوید.
5. Workflow با نام **Build Nabz Football APK** را اجرا کنید.
6. بعد از اتمام Build، فایل Artifact با نام `nabz-football-debug-apk` را دریافت کنید.

این پروژه برای GitHub Actions نیازی به Android Studio ندارد؛ Workflow خودش Gradle 8.9 و JDK 17 را آماده می‌کند.

## تست

در محیط دارای Android SDK و Gradle:

```bash
gradle test
```

برای APK:

```bash
gradle assembleDebug
```

در محیط فعلی من Android SDK/Gradle قابل اجرای محلی در دسترس نبود، بنابراین APK را جعل نکرده‌ام و ادعای Build موفق نمی‌کنم. فایل‌های پروژه، Manifest، Gradle، کد Kotlin، Backend، تست‌های واحد و Workflow ساخت بررسی و آماده شده‌اند.

## نکته مهم درباره متن خبر

NewsAPI ممکن است محتوای مقاله را کوتاه‌شده برگرداند. اپ عنوان/خلاصه/محتوای در دسترس API را نمایش می‌دهد و برای مطالعه کامل دکمه «مشاهده منبع اصلی خبر» دارد؛ اپ نباید متن کامل مقاله ناشر را بدون مجوز کپی کند.

## ساختار

```text
NabzFootball/
├── app/
│   ├── src/main/java/ir/nabzfootball/app/
│   │   ├── MainActivity.kt
│   │   ├── data/
│   │   │   ├── Api.kt
│   │   │   └── Repository.kt
│   │   ├── model/Models.kt
│   │   └── ui/
│   │       ├── Theme.kt
│   │       └── ViewModel.kt
│   ├── src/main/res/
│   │   ├── drawable/ic_nabz_football.jpg
│   │   └── values/
│   └── build.gradle.kts
├── backend/
│   ├── src/server.js
│   ├── package.json
│   └── .env.example
├── .github/workflows/android.yml
├── local.properties.example
├── settings.gradle.kts
└── build.gradle.kts
```
