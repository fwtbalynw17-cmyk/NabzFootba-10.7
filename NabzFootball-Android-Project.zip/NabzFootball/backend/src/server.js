import 'dotenv/config';
import express from 'express';
import cors from 'cors';

const app = express();
const port = Number(process.env.PORT || 8080);
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json());

const newsKey = process.env.NEWS_API_KEY;
const footballKey = process.env.FOOTBALL_API_KEY;
const cache = new Map();

function cached(key, ttlMs, loader) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.time < ttlMs) return Promise.resolve(hit.value);
  return loader().then(value => { cache.set(key, { time: Date.now(), value }); return value; });
}

async function news(q) {
  if (!newsKey) throw new Error('NEWS_API_KEY is not configured');
  const url = new URL('https://newsapi.org/v2/everything');
  url.searchParams.set('q', q);
  url.searchParams.set('sortBy', 'publishedAt');
  url.searchParams.set('pageSize', '50');
  const r = await fetch(url, { headers: { 'X-Api-Key': newsKey } });
  const data = await r.json();
  if (!r.ok || data.status !== 'ok') throw new Error(data.message || 'News API error');
  return data;
}

async function football(path, params = {}) {
  if (!footballKey) throw new Error('FOOTBALL_API_KEY is not configured');
  const url = new URL(`https://v3.football.api-sports.io/${path}`);
  Object.entries(params).forEach(([k, v]) => { if (v !== undefined && v !== null) url.searchParams.set(k, String(v)); });
  const r = await fetch(url, { headers: { 'x-apisports-key': footballKey } });
  const data = await r.json();
  if (!r.ok) throw new Error(data.message || `API-Football HTTP ${r.status}`);
  return data;
}

function qFor(category, q) {
  if (q) return q;
  if (category === 'iran') return 'فوتبال ایران OR لیگ برتر ایران OR تیم ملی ایران';
  if (category === 'world') return 'football OR soccer OR Champions League';
  if (category === 'breaking') return 'football AND (breaking OR فوری OR "خبر فوری")';
  return 'football OR فوتبال';
}

app.get('/health', (_req, res) => res.json({ ok: true, service: 'nabz-football-backend' }));

app.get('/api/news', async (req, res) => {
  try {
    const q = qFor(req.query.category, req.query.q);
    const data = await cached(`news:${q}`, 60_000, () => news(q));
    res.json(data);
  } catch (e) { res.status(502).json({ status: 'error', message: e.message }); }
});

app.get('/api/live', async (_req, res) => {
  try { res.json(await cached('live', 12_000, () => football('fixtures', { live: 'all' }))); }
  catch (e) { res.status(502).json({ message: e.message }); }
});

app.get('/api/fixtures', async (req, res) => {
  try { res.json(await cached(`next:${req.query.next || 20}`, 60_000, () => football('fixtures', { next: req.query.next || 20 }))); }
  catch (e) { res.status(502).json({ message: e.message }); }
});

app.get('/api/standings', async (req, res) => {
  try {
    const league = Number(req.query.league || 39);
    const season = Number(req.query.season || new Date().getUTCFullYear());
    res.json(await cached(`standings:${league}:${season}`, 3_600_000, () => football('standings', { league, season })));
  } catch (e) { res.status(502).json({ message: e.message }); }
});

app.get('/api/search', async (req, res) => {
  try {
    const q = String(req.query.q || '').trim();
    if (!q) return res.json({ news: { status: 'ok', articles: [] }, teams: [], players: [] });
    const season = Number(req.query.season || new Date().getUTCFullYear());
    const [n, t, p] = await Promise.all([
      news(q),
      football('teams', { search: q }),
      football('players', { search: q, season })
    ]);
    res.json({ news: n, teams: t.response || [], players: p.response || [] });
  } catch (e) { res.status(502).json({ message: e.message }); }
});

app.listen(port, () => console.log(`Nabz Football backend listening on :${port}`));
