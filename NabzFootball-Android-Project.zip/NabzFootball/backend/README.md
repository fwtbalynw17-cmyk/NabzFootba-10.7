# Nabz Football Backend

Optional production proxy for Nabz Football. It keeps NewsAPI and API-Football keys off the APK.

## Run
1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Put your real keys in `.env`.
4. Run `npm install` then `npm start`.
5. Set Android `BACKEND_URL` to the deployed URL, e.g. `https://your-domain.example/`.

The app expects:
- `GET /api/news?category=latest|iran|world|breaking`
- `GET /api/news?q=...`
- `GET /api/live`
- `GET /api/fixtures?next=20`
- `GET /api/standings?league=39&season=2026`
- `GET /api/search?q=...&season=2026`

Deploy this folder to a Node-compatible host such as Render, Railway, Fly.io, or your own VPS. Do not commit `.env`.
