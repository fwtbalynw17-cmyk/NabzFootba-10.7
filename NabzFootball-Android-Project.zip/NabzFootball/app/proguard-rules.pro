# Nabz Football release rules.
