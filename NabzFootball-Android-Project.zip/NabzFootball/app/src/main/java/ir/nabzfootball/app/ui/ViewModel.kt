package ir.nabzfootball.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.nabzfootball.app.data.FootballRepository
import ir.nabzfootball.app.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class NabzViewModel(private val repo: FootballRepository = FootballRepository()) : ViewModel() {
    private val _news = MutableStateFlow<List<Article>>(emptyList())
    val news: StateFlow<List<Article>> = _news.asStateFlow()
    private val _iranNews = MutableStateFlow<List<Article>>(emptyList())
    val iranNews: StateFlow<List<Article>> = _iranNews.asStateFlow()
    private val _worldNews = MutableStateFlow<List<Article>>(emptyList())
    val worldNews: StateFlow<List<Article>> = _worldNews.asStateFlow()
    private val _breaking = MutableStateFlow<List<Article>>(emptyList())
    val breaking: StateFlow<List<Article>> = _breaking.asStateFlow()
    private val _live = MutableStateFlow<List<Match>>(emptyList())
    val live: StateFlow<List<Match>> = _live.asStateFlow()
    private val _upcoming = MutableStateFlow<List<Match>>(emptyList())
    val upcoming: StateFlow<List<Match>> = _upcoming.asStateFlow()
    private val _standings = MutableStateFlow<List<StandingRow>>(emptyList())
    val standings: StateFlow<List<StandingRow>> = _standings.asStateFlow()
    private val _search = MutableStateFlow(SearchResults())
    val search: StateFlow<SearchResults> = _search.asStateFlow()
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    private var liveJob: Job? = null

    fun loadHome() = launch {
        _loading.value = true; _error.value = null
        runCatching {
            _news.value = repo.news("latest")
            _iranNews.value = repo.news("iran")
            _worldNews.value = repo.news("world")
            _breaking.value = repo.news("breaking")
            _upcoming.value = repo.upcoming()
        }.onFailure { _error.value = friendlyError(it) }
        _loading.value = false
    }

    fun loadNews(category: String) = launch {
        _loading.value = true; _error.value = null
        runCatching { repo.news(category) }.onSuccess {
            when (category) { "iran" -> _iranNews.value = it; "world" -> _worldNews.value = it; "breaking" -> _breaking.value = it; else -> _news.value = it }
        }.onFailure { _error.value = friendlyError(it) }
        _loading.value = false
    }

    fun startLivePolling() {
        if (liveJob?.isActive == true) return
        liveJob = viewModelScope.launch {
            while (true) {
                runCatching { repo.live() }.onSuccess { _live.value = it }.onFailure { _error.value = friendlyError(it) }
                delay(15_000)
            }
        }
    }

    fun stopLivePolling() { liveJob?.cancel(); liveJob = null }

    fun loadStandings(league: Int) = launch {
        _loading.value = true; _error.value = null
        runCatching { repo.standings(league) }.onSuccess { _standings.value = it }.onFailure { _error.value = friendlyError(it) }
        _loading.value = false
    }

    fun search(q: String) = launch {
        _loading.value = true; _error.value = null
        runCatching { repo.search(q) }.onSuccess { _search.value = it }.onFailure { _error.value = friendlyError(it) }
        _loading.value = false
    }

    private fun launch(block: suspend () -> Unit) = viewModelScope.launch { block() }
    private fun friendlyError(t: Throwable): String = t.message?.takeIf { it.isNotBlank() } ?: "خطا در دریافت اطلاعات از اینترنت"
}
