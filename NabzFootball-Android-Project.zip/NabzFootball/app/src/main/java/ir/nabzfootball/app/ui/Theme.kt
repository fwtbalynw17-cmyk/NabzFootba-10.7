package ir.nabzfootball.app.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Green = Color(0xFF8BC34A)
private val Red = Color(0xFFD32F2F)
private val Dark = Color(0xFF0B0F0D)
private val Surface = Color(0xFF121814)
private val White = Color(0xFFF8FAF8)

@Composable
fun NabzTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Green,
        secondary = Red,
        background = Dark,
        surface = Surface,
        onPrimary = Color.Black,
        onSecondary = Color.White,
        onBackground = White,
        onSurface = White,
        error = Red
    )
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
