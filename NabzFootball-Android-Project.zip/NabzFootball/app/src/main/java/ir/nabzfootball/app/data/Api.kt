package ir.nabzfootball.app.data

import ir.nabzfootball.app.BuildConfig
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import okhttp3.OkHttpClient
import okhttp3.Interceptor
import java.util.concurrent.TimeUnit

private class ApiKeyInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): okhttp3.Response {
        val request = chain.request()
        val host = request.url.host
        val builder = request.newBuilder()
        if (host.contains("newsapi.org") && BuildConfig.NEWS_API_KEY.isNotBlank()) {
            builder.header("X-Api-Key", BuildConfig.NEWS_API_KEY)
        }
        if (host.contains("api-football.com") && BuildConfig.FOOTBALL_API_KEY.isNotBlank()) {
            builder.header("x-apisports-key", BuildConfig.FOOTBALL_API_KEY)
        }
        return chain.proceed(builder.build())
    }
}

object ApiFactory {
    private val client = OkHttpClient.Builder()
        .addInterceptor(ApiKeyInterceptor())
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private fun retrofit(baseUrl: String) = Retrofit.Builder()
        .baseUrl(baseUrl.ensureSlash())
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val news: NewsApi by lazy { retrofit("https://newsapi.org/").create(NewsApi::class.java) }
    val football: FootballApi by lazy { retrofit("https://v3.football.api-sports.io/").create(FootballApi::class.java) }
    val backend: BackendApi? by lazy {
        BuildConfig.BACKEND_URL.takeIf { it.isNotBlank() }?.let { retrofit(it).create(BackendApi::class.java) }
    }

    private fun String.ensureSlash() = if (endsWith('/')) this else "$this/"
}

interface NewsApi {
    @GET("v2/everything")
    suspend fun everything(
        @Query("q") q: String,
        @Query("language") language: String? = null,
        @Query("sortBy") sortBy: String = "publishedAt",
        @Query("pageSize") pageSize: Int = 50
    ): NewsResponse
}

interface FootballApi {
    @GET("fixtures") suspend fun fixtures(
        @Query("live") live: String? = null,
        @Query("next") next: Int? = null
    ): FootballFixturesResponse

    @GET("standings") suspend fun standings(
        @Query("league") league: Int,
        @Query("season") season: Int
    ): StandingsResponse

    @GET("teams") suspend fun teams(@Query("search") search: String): TeamsResponse

    @GET("players") suspend fun players(@Query("search") search: String, @Query("season") season: Int): PlayersResponse
}

interface BackendApi {
    @GET("api/news") suspend fun news(@Query("category") category: String = "latest", @Query("q") q: String? = null): NewsResponse
    @GET("api/live") suspend fun live(): FootballFixturesResponse
    @GET("api/fixtures") suspend fun fixtures(@Query("next") next: Int = 20): FootballFixturesResponse
    @GET("api/standings") suspend fun standings(@Query("league") league: Int, @Query("season") season: Int): StandingsResponse
    @GET("api/search") suspend fun search(@Query("q") q: String, @Query("season") season: Int): SearchResponse
}

data class NewsResponse(val status: String? = null, val articles: List<NewsArticleDto> = emptyList())
data class NewsArticleDto(
    val title: String? = null, val description: String? = null, val content: String? = null,
    val urlToImage: String? = null, val publishedAt: String? = null, val url: String? = null,
    val source: NewsSourceDto? = null
)
data class NewsSourceDto(val name: String? = null)

data class FootballFixturesResponse(val response: List<FixtureDto> = emptyList())
data class FixtureDto(
    val fixture: FixtureInfoDto? = null,
    val league: LeagueDto? = null,
    val teams: FixtureTeamsDto? = null,
    val goals: GoalsDto? = null
)
data class FixtureInfoDto(val id: Int? = null, val date: String? = null, val status: StatusDto? = null)
data class StatusDto(val short: String? = null, val long: String? = null, val elapsed: Int? = null)
data class LeagueDto(val name: String? = null, val country: String? = null)
data class FixtureTeamsDto(val home: TeamDto? = null, val away: TeamDto? = null)
data class TeamDto(val id: Int? = null, val name: String? = null, val logo: String? = null)
data class GoalsDto(val home: Int? = null, val away: Int? = null)

data class StandingsResponse(val response: List<StandingRootDto> = emptyList())
data class StandingRootDto(val league: StandingLeagueDto? = null)
data class StandingLeagueDto(val standings: List<List<StandingDto>>? = null)
data class StandingDto(val rank: Int? = null, val team: TeamDto? = null, val points: Int? = null, val all: AllDto? = null, val goalsDiff: Int? = null)
data class AllDto(val played: Int? = null)

data class TeamsResponse(val response: List<TeamRootDto> = emptyList())
data class TeamRootDto(val team: TeamDto? = null)
data class PlayersResponse(val response: List<PlayerRootDto> = emptyList())
data class PlayerRootDto(val player: PlayerDto? = null)
data class PlayerDto(val id: Int? = null, val name: String? = null, val photo: String? = null, val age: Int? = null, val nationality: String? = null)
data class SearchResponse(val news: NewsResponse? = null, val teams: List<TeamRootDto> = emptyList(), val players: List<PlayerRootDto> = emptyList())
