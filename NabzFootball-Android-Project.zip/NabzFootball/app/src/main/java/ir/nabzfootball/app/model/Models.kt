package ir.nabzfootball.app.model

import java.io.Serializable

data class Article(
    val title: String,
    val description: String?,
    val content: String?,
    val imageUrl: String?,
    val publishedAt: String?,
    val source: String,
    val url: String
) : Serializable

data class Match(val id: Int, val home: String, val away: String, val homeLogo: String?, val awayLogo: String?, val homeScore: Int?, val awayScore: Int?, val minute: String?, val status: String, val league: String, val country: String?, val date: String?)
data class StandingRow(val rank: Int, val team: String, val logo: String?, val played: Int, val points: Int, val goalsDiff: Int)
data class Team(val id: Int, val name: String, val logo: String?, val country: String?)
data class Player(val id: Int, val name: String, val photo: String?, val age: Int?, val nationality: String?)
data class SearchResults(val articles: List<Article> = emptyList(), val teams: List<Team> = emptyList(), val players: List<Player> = emptyList())
