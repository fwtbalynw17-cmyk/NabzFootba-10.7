package ir.nabzfootball.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import ir.nabzfootball.app.model.*
import ir.nabzfootball.app.ui.NabzTheme
import ir.nabzfootball.app.ui.NabzViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NabzTheme { NabzApp() } }
    }
}

private data class NavItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)
private val bottomItems = listOf(
    NavItem("home", "خانه", Icons.Filled.Home),
    NavItem("news", "اخبار", Icons.Filled.Article),
    NavItem("live", "زنده", Icons.Filled.LiveTv),
    NavItem("matches", "مسابقات", Icons.Filled.SportsSoccer),
    NavItem("more", "بیشتر", Icons.Filled.MoreHoriz)
)

@Composable
private fun NabzApp(vm: NabzViewModel = viewModel()) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    val context = LocalContext.current
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                if (current in bottomItems.map { it.route }) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        bottomItems.forEach { item ->
                            NavigationBarItem(
                                selected = current == item.route,
                                onClick = { nav.navigate(item.route) { launchSingleTop = true } },
                                icon = { Icon(item.icon, null) },
                                label = { Text(item.label) },
                                colors = NavigationBarItemDefaults.colors(indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = .18f))
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
                composable("home") { HomeScreen(vm, nav) }
                composable("news") { NewsScreen(vm, nav, "latest", "آخرین اخبار") }
                composable("iran") { NewsScreen(vm, nav, "iran", "اخبار فوتبال ایران") }
                composable("world") { NewsScreen(vm, nav, "world", "اخبار فوتبال جهان") }
                composable("breaking") { NewsScreen(vm, nav, "breaking", "اخبار فوری") }
                composable("live") { LiveScreen(vm) }
                composable("matches") { MatchesScreen(vm) }
                composable("tables") { StandingsScreen(vm) }
                composable("search") { SearchScreen(vm, nav) }
                composable("more") { MoreScreen(nav) }
                composable("settings") { SettingsScreen() }
                composable("teams") { SearchScreen(vm, nav, initialTab = 1) }
                composable("players") { SearchScreen(vm, nav, initialTab = 2) }
                composable("article") {
                    val article = nav.previousBackStackEntry?.savedStateHandle?.get<Article>("article")
                    if (article != null) ArticleDetailScreen(article) else EmptyState("خبر پیدا نشد")
                }
            }
        }
    }
}

@Composable
private fun Header(nav: NavHostController? = null, title: String = "نبض فوتبال") {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(ir.nabzfootball.app.R.drawable.ic_nabz_football), null, Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("نبض فوتبال | Nabz Football", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
            }
        }
        if (nav != null) IconButton(onClick = { nav.navigate("search") }) { Icon(Icons.Filled.Search, "جستجو") }
    }
}

@Composable
private fun HomeScreen(vm: NabzViewModel, nav: NavHostController) {
    val news by vm.news.collectAsState(); val iran by vm.iranNews.collectAsState(); val world by vm.worldNews.collectAsState(); val loading by vm.loading.collectAsState(); val error by vm.error.collectAsState()
    LaunchedEffect(Unit) { if (news.isEmpty()) vm.loadHome() }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Header(nav) }
        item { QuickTabs(nav) }
        item { SectionTitle("آخرین اخبار", "news", nav) }
        if (loading && news.isEmpty()) item { Loading() }
        items(news.take(10)) { ArticleCard(it) { navToArticle(nav, it) } }
        if (news.isEmpty() && !loading) item { EmptyState(error ?: "هنوز خبری دریافت نشده است. کلید API یا Backend را تنظیم کنید.") }
        item { SectionTitle("فوتبال ایران", "iran", nav) }
        items(iran.take(4)) { ArticleCard(it) { navToArticle(nav, it) } }
        item { SectionTitle("فوتبال جهان", "world", nav) }
        items(world.take(4)) { ArticleCard(it) { navToArticle(nav, it) } }
    }
}

@Composable
private fun QuickTabs(nav: NavHostController) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("ایران" to "iran", "جهان" to "world", "فوری" to "breaking", "زنده" to "live").forEach { (label, route) ->
            AssistChip(onClick = { nav.navigate(route) }, label = { Text(label) }, leadingIcon = { Icon(if (route == "live") Icons.Filled.LiveTv else Icons.Filled.FlashOn, null) })
        }
    }
}

@Composable
private fun NewsScreen(vm: NabzViewModel, nav: NavHostController, category: String, title: String) {
    val list by when(category) { "iran" -> vm.iranNews; "world" -> vm.worldNews; "breaking" -> vm.breaking; else -> vm.news }.collectAsState()
    val loading by vm.loading.collectAsState(); val error by vm.error.collectAsState()
    LaunchedEffect(category) { if (list.isEmpty()) vm.loadNews(category) }
    Column(Modifier.fillMaxSize()) {
        Header(nav, title)
        if (loading && list.isEmpty()) Loading()
        LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
            items(list) { ArticleCard(it) { navToArticle(nav, it) } }
            if (list.isEmpty() && !loading) item { EmptyState(error ?: "خبری پیدا نشد") }
        }
    }
}

@Composable
private fun LiveScreen(vm: NabzViewModel) {
    val live by vm.live.collectAsState(); val error by vm.error.collectAsState()
    DisposableEffect(Unit) { vm.startLivePolling(); onDispose { vm.stopLivePolling() } }
    Column(Modifier.fillMaxSize()) {
        Header(title = "بازی‌های زنده")
        if (live.isEmpty()) EmptyState(error ?: "در حال حاضر بازی زنده‌ای دریافت نشد")
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(live) { MatchCard(it, live = true) } }
    }
}

@Composable
private fun MatchesScreen(vm: NabzViewModel) {
    val list by vm.upcoming.collectAsState()
    LaunchedEffect(Unit) { if (list.isEmpty()) vm.loadHome() }
    Column(Modifier.fillMaxSize()) {
        Header(title = "مسابقات آینده")
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(list) { MatchCard(it, live = false) } }
    }
}

@Composable
private fun MatchCard(m: Match, live: Boolean) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(m.league, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                Text(m.country.orEmpty(), color = Color.LightGray, fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                TeamBadge(m.home, m.homeLogo)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${m.homeScore ?: "-"}  -  ${m.awayScore ?: "-"}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(if (live) (m.minute ?: m.status) else m.status, color = if (live) MaterialTheme.colorScheme.secondary else Color.LightGray, fontSize = 12.sp)
                }
                TeamBadge(m.away, m.awayLogo)
            }
        }
    }
}

@Composable
private fun TeamBadge(name: String, logo: String?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(95.dp)) {
        if (logo != null) AsyncImage(model = logo, contentDescription = name, modifier = Modifier.size(42.dp)) else Icon(Icons.Filled.Shield, null, Modifier.size(42.dp))
        Text(name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StandingsScreen(vm: NabzViewModel) {
    val rows by vm.standings.collectAsState()
    var league by remember { mutableIntStateOf(39) }
    val leagues = listOf(39 to "انگلیس", 140 to "اسپانیا", 135 to "ایتالیا", 78 to "آلمان", 61 to "فرانسه", 290 to "ایران")
    LaunchedEffect(league) { vm.loadStandings(league) }
    Column(Modifier.fillMaxSize()) {
        Header(title = "جدول لیگ‌ها")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            leagues.forEach { (id, name) -> FilterChip(selected = league == id, onClick = { league = id }, label = { Text(name) }) }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(contentPadding = PaddingValues(12.dp)) {
            item { Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("تیم"); Text("بازی"); Text("امتیاز") } }
            itemsIndexed(rows) { index, r ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = if (index < 4) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surface.copy(alpha = .7f))) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${r.rank}", Modifier.width(30.dp), fontWeight = FontWeight.Bold)
                        if (r.logo != null) AsyncImage(r.logo, null, Modifier.size(28.dp))
                        Text(r.team, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${r.played}", Modifier.width(40.dp)); Text("${r.points}", Modifier.width(50.dp), fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (rows.isEmpty()) item { EmptyState("جدول دریافت نشد. کلید فوتبال یا Backend را تنظیم کنید.") }
        }
    }
}

@Composable
private fun SearchScreen(vm: NabzViewModel, nav: NavHostController, initialTab: Int = 0) {
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(initialTab) }
    val results by vm.search.collectAsState()
    val loading by vm.loading.collectAsState()
    Column(Modifier.fillMaxSize()) {
        Header(nav, "جست‌وجو")
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp), singleLine = true, label = { Text("خبر، تیم یا بازیکن") }, trailingIcon = { IconButton(onClick = { vm.search(q) }) { Icon(Icons.Filled.Search, null) } })
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("اخبار", "تیم‌ها", "بازیکنان").forEachIndexed { i, label -> FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) }) }
        }
        if (loading) Loading()
        LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp)) {
            when (tab) {
                0 -> items(results.articles) { ArticleCard(it) { navToArticle(nav, it) } }
                1 -> items(results.teams) { TeamResultCard(it) }
                2 -> items(results.players) { PlayerResultCard(it) }
            }
            if (!loading && q.isNotBlank() && results.articles.isEmpty() && results.teams.isEmpty() && results.players.isEmpty()) item { EmptyState("نتیجه‌ای پیدا نشد") }
        }
    }
}

@Composable
private fun MoreScreen(nav: NavHostController) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(nav, "بیشتر")
        MoreButton("جدول لیگ‌ها", Icons.Filled.TableChart) { nav.navigate("tables") }
        MoreButton("تیم‌ها", Icons.Filled.Groups) { nav.navigate("teams") }
        MoreButton("بازیکنان", Icons.Filled.Person) { nav.navigate("players") }
        MoreButton("جست‌وجو", Icons.Filled.Search) { nav.navigate("search") }
        MoreButton("تنظیمات", Icons.Filled.Settings) { nav.navigate("settings") }
        Card(Modifier.padding(16.dp).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("نبض فوتبال", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("نسخه 1.0.0 • بدون تبلیغات", color = Color.LightGray, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp)); Text("داده‌های خبری و فوتبالی به‌صورت آنلاین از API دریافت می‌شوند.", fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(title = "تنظیمات")
        var notifications by remember { mutableStateOf(false) }
        ListItem(headlineContent = { Text("اعلان اخبار مهم") }, supportingContent = { Text("زیرساخت اعلان برای فعال‌سازی آینده آماده است") }, trailingContent = { Switch(notifications, { notifications = it }) })
        ListItem(headlineContent = { Text("بروزرسانی زنده") }, supportingContent = { Text("بازی‌های زنده در زمان مشاهده هر ۱۵ ثانیه تازه می‌شوند") })
        ListItem(headlineContent = { Text("حریم API") }, supportingContent = { Text("برای انتشار عمومی، Backend/Proxy توصیه می‌شود تا کلیدها داخل APK قرار نگیرند") })
    }
}

@Composable
private fun ArticleCard(article: Article, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (article.imageUrl != null) AsyncImage(model = article.imageUrl, contentDescription = null, modifier = Modifier.size(92.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
            Column(Modifier.weight(1f)) {
                Text(article.title, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis, lineHeight = 19.sp)
                Spacer(Modifier.height(6.dp)); Text("${article.source} • ${formatDate(article.publishedAt)}", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
                if (!article.description.isNullOrBlank()) { Spacer(Modifier.height(4.dp)); Text(article.description!!, color = Color.LightGray, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun ArticleDetailScreen(article: Article) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Image(painterResource(ir.nabzfootball.app.R.drawable.ic_nabz_football), null, Modifier.fillMaxWidth().height(120.dp), contentScale = ContentScale.Crop)
        Column(Modifier.padding(16.dp)) {
            Text(article.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
            Spacer(Modifier.height(8.dp)); Text("${article.source} • ${formatDate(article.publishedAt)}", color = MaterialTheme.colorScheme.primary)
            if (article.imageUrl != null) { Spacer(Modifier.height(14.dp)); AsyncImage(article.imageUrl, null, Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop) }
            Spacer(Modifier.height(16.dp)); Text(article.description.orEmpty(), fontSize = 16.sp, lineHeight = 26.sp)
            Spacer(Modifier.height(10.dp)); Text(article.content.orEmpty().removeSuffix(" [+chars]"), fontSize = 15.sp, lineHeight = 26.sp)
            Spacer(Modifier.height(18.dp)); Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(article.url))) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.OpenInBrowser, null); Spacer(Modifier.width(8.dp)); Text("مشاهده منبع اصلی خبر") }
            Spacer(Modifier.height(10.dp)); Text("نکته: متن کامل مقاله فقط در صورتی نمایش داده می‌شود که API آن را ارائه کند؛ برای مطالعه کامل همیشه از منبع اصلی استفاده کنید.", color = Color.LightGray, fontSize = 12.sp)
        }
    }
}

@Composable
private fun TeamResultCard(team: Team) { ListItem(leadingContent = { if (team.logo != null) AsyncImage(team.logo, null, Modifier.size(42.dp)) else Icon(Icons.Filled.Shield, null) }, headlineContent = { Text(team.name) }, supportingContent = { Text(team.country ?: "تیم فوتبال") }) }
@Composable
private fun PlayerResultCard(player: Player) { ListItem(leadingContent = { if (player.photo != null) AsyncImage(player.photo, null, Modifier.size(42.dp).clip(RoundedCornerShape(50))) else Icon(Icons.Filled.Person, null) }, headlineContent = { Text(player.name) }, supportingContent = { Text(listOfNotNull(player.nationality, player.age?.let { "$it سال" }).joinToString(" • ")) }) }

@Composable private fun MoreButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) { ListItem(modifier = Modifier.clickable(onClick = onClick), leadingContent = { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) }, headlineContent = { Text(label, fontWeight = FontWeight.Medium) }, trailingContent = { Icon(Icons.Filled.ChevronLeft, null) }) }
@Composable private fun SectionTitle(title: String, route: String, nav: NavHostController) { Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold); TextButton(onClick = { nav.navigate(route) }) { Text("مشاهده همه") } } }
@Composable private fun Loading() { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
@Composable private fun EmptyState(message: String) { Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) { Text(message, color = Color.LightGray, textAlign = androidx.compose.ui.text.style.TextAlign.Center) } }
private fun navToArticle(nav: NavHostController, article: Article) { nav.currentBackStackEntry?.savedStateHandle?.set("article", article); nav.navigate("article") }
private fun formatDate(value: String?): String = value?.replace('T', ' ')?.replace("Z", "")?.take(16) ?: "زمان نامشخص"
