package ir.nabzfootball.app.data

import ir.nabzfootball.app.BuildConfig
import ir.nabzfootball.app.model.*

class FootballRepository {
    private val backend get() = ApiFactory.backend
    private val season get() = java.time.LocalDate.now().year

    suspend fun news(category: String = "latest", query: String? = null): List<Article> {
        val response = backend?.news(category, query) ?: run {
            val q = query ?: when (category) {
                "iran" -> "فوتبال ایران OR لیگ برتر ایران OR تیم ملی ایران"
                "world" -> "football OR soccer OR Champions League"
                "breaking" -> "football AND (breaking OR فوری OR خبر فوری)"
                else -> "football OR فوتبال"
            }
            ApiFactory.news.everything(q = q, sortBy = "publishedAt", pageSize = 50)
        }
        return response.articles.mapNotNull { a ->
            val url = a.url ?: return@mapNotNull null
            Article(a.title ?: "بدون عنوان", a.description, a.content, a.urlToImage, a.publishedAt, a.source?.name ?: "منبع نامشخص", url)
        }
    }

    suspend fun live(): List<Match> {
        val response = backend?.live() ?: ApiFactory.football.fixtures(live = "all")
        return response.response.mapNotNull(::mapMatch)
    }

    suspend fun upcoming(): List<Match> {
        val response = backend?.fixtures(20) ?: ApiFactory.football.fixtures(next = 20)
        return response.response.mapNotNull(::mapMatch)
    }

    suspend fun standings(league: Int): List<StandingRow> {
        val response = backend?.standings(league, season) ?: ApiFactory.football.standings(league, season)
        return response.response.firstOrNull()?.league?.standings?.orEmpty()?.firstOrNull().orEmpty().map {
            StandingRow(it.rank ?: 0, it.team?.name ?: "-", it.team?.logo, it.all?.played ?: 0, it.points ?: 0, it.goalsDiff ?: 0)
        }
    }

    suspend fun search(query: String): SearchResults {
        if (query.isBlank()) return SearchResults()
        val b = backend
        if (b != null) {
            val r = b.search(query, season)
            return SearchResults(
                r.news?.articles.orEmpty().mapNotNull(::mapArticle),
                r.teams.mapNotNull { it.team?.let { t -> Team(t.id ?: 0, t.name ?: "-", t.logo, null) } },
                r.players.mapNotNull { it.player?.let { p -> Player(p.id ?: 0, p.name ?: "-", p.photo, p.age, p.nationality) } }
            )
        }
        val articles = news("latest", query)
        val teams = if (BuildConfig.FOOTBALL_API_KEY.isNotBlank()) ApiFactory.football.teams(query).response.mapNotNull { it.team?.let { t -> Team(t.id ?: 0, t.name ?: "-", t.logo, null) } } else emptyList()
        val players = if (BuildConfig.FOOTBALL_API_KEY.isNotBlank()) ApiFactory.football.players(query, season).response.mapNotNull { it.player?.let { p -> Player(p.id ?: 0, p.name ?: "-", p.photo, p.age, p.nationality) } } else emptyList()
        return SearchResults(articles, teams, players)
    }

    private fun mapArticle(a: NewsArticleDto): Article? {
        val url = a.url ?: return null
        return Article(a.title ?: "بدون عنوان", a.description, a.content, a.urlToImage, a.publishedAt, a.source?.name ?: "منبع نامشخص", url)
    }

    private fun mapMatch(x: FixtureDto): Match? {
        val f = x.fixture ?: return null
        val t = x.teams ?: return null
        val home = t.home ?: return null
        val away = t.away ?: return null
        return Match(
            id = f.id ?: 0,
            home = home.name ?: "خانه",
            away = away.name ?: "میهمان",
            homeLogo = home.logo,
            awayLogo = away.logo,
            homeScore = x.goals?.home,
            awayScore = x.goals?.away,
            minute = f.status?.elapsed?.let { "$it'" },
            status = f.status?.long ?: f.status?.short ?: "-",
            league = x.league?.name ?: "مسابقه",
            country = x.league?.country,
            date = f.date
        )
    }
}
