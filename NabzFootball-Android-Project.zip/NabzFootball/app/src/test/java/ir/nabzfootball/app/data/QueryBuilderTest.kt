package ir.nabzfootball.app.data

import org.junit.Assert.assertTrue
import org.junit.Test

class QueryBuilderTest {
    @Test fun iranQueryContainsIranFootballTerms() {
        val q = "فوتبال ایران OR لیگ برتر ایران OR تیم ملی ایران"
        assertTrue(q.contains("فوتبال ایران"))
        assertTrue(q.contains("لیگ برتر ایران"))
    }

    @Test fun worldQueryContainsFootball() {
        val q = "football OR soccer OR Champions League"
        assertTrue(q.contains("football"))
    }
}
